package tests;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import codesjava.CodesJava;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class MyTest {

//    @Test
//    void t1() {
//        Assertions.assertEquals(0, CodesJava.m(), "wrong");
//    }
//
//    @Test
//    void t2() {
//        Assertions.assertEquals(0, CodesJava.m(), "wrong");
//    }
//
//    @Test
//    void t3() {
//        Assertions.assertEquals(1, CodesJava.m(), "wrong");
//    }
}
