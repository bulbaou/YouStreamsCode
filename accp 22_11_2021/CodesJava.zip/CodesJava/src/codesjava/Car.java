/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codesjava;

/**
 *
 * @author Александр
 */
public class Car {
    @DefaultValue
    String brand;
    
    int odometr;

    public Car(int odometr) {
        this.odometr = odometr;
    }

    @Override
    public String toString() {
        return "Car{" + "brand=" + brand + ", odometr=" + odometr + '}';
    }

    
    
    
}
