package codesjava;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Random;

public class FullStudent {

    private String name;
    private List<Integer> grades = new ArrayList<>();

    public FullStudent(String name, Integer... grades) {
        this(name, Arrays.asList(grades));
    }

    public FullStudent(String name, List<Integer> grades) {
        this.name = name;
        for (Integer x : grades) {
            addGrade(x);
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Integer> getGrades() {
        return new ArrayList<>(grades);
    }

    public void addGrade(int x) {
        if (x >= 2 && x <= 5) {
            grades.add(x);
        } else {
            throw new IllegalArgumentException("wrong grade");
        }
    }

    @Override
    public String toString() {
        return "FullStudent{" + "name=" + name + ", grades=" + grades + '}';
    }

    @Override   
    public int hashCode() {
        int hash = 7;
        hash = 17 * hash + Objects.hashCode(this.name);
        hash = 17 * hash + Objects.hashCode(this.grades);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final FullStudent other = (FullStudent) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        if (!Objects.equals(this.grades, other.grades)) {
            return false;
        }
        return true;
    }
}
