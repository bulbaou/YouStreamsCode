package codesjava;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class CodesJava {

    public static void main(String[] args) throws Exception {
        FullStudent stud1 = new FullStudent("pete", 2, 3, 4);
        Cat cat = new Cat(null);
        Car car = new Car(123);
//        System.out.println(Arrays.toString(cat.getClass().getDeclaredField("name").getAnnotations()));
//        System.out.println(cat.getClass().getDeclaredField("name").isAnnotationPresent(DefaultValue.class));
//        рефлексия
        setName(stud1, cat, car);

        System.out.println(stud1);
        System.out.println(cat);
        System.out.println(car);
    }

    public static void setName(Object... objects) {
        String defaultName = "Эй, ты!";
        for (Object ob : objects) {
            Arrays.asList(ob.getClass().getDeclaredFields())
                    .stream()
                    .peek(x->System.out.println(x+"    before  " + x.isAnnotationPresent(DefaultValue.class)))
                    .filter(x ->x.isAnnotationPresent(DefaultValue.class))
                    .peek(x->System.out.println(x+"    after  "))
                    .filter(x -> x.getType() == String.class)
                    .forEach(x -> setValue(x, ob, defaultName));
        }
    }

    public static void setValue(Field f, Object ob, Object value) {
        try {
            f.setAccessible(true);
            f.set(ob, value);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }

    }
}
//аннотации


class Defaults{
    public String def1(){
        return "Эй, ты!";
    }
}

class Defaults2{
    public Integer def1(){
        return 3;
    }
}