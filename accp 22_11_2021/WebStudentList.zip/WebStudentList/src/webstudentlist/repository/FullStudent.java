/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webstudentlist.repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Александр
 */
public class FullStudent {

    Integer id;
    String name;
    List<Integer> grades = new ArrayList<>();
    
    public FullStudent(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public FullStudent(Integer id, String name, List<Integer> grades) {
        this(id, name);
        this.grades.addAll(grades);
    }

    @Override
    public String toString() {
        return "FullStudent{" + "id=" + id + ", name=" + name + ", grades=" + grades + '}';
    }
    
}
