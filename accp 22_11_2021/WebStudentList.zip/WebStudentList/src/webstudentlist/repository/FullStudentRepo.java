/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webstudentlist.repository;

import webstudentlist.repository.StudentRepo;
import webstudentlist.repository.Student;
import webstudentlist.repository.GradesRepo;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
public class FullStudentRepo {

    @Autowired
    StudentRepo studRepo;
    @Autowired
    GradesRepo gradesRepo;

    public List<FullStudent> findAll() {
        Iterable<Student> studList= studRepo.findAll();
        return StreamSupport.stream(studList.spliterator(), false)
                .map(x->new FullStudent(x.id,x.name))
                .peek(x->x.grades=gradesRepo.findAllByStudent(x.id)
                    .stream().map(y->y.grade).collect(Collectors.toList()))
                .collect(Collectors.toList());   
    }
    public List<FullStudent> findbyID(int id) {
        Iterable<Student> studList= List.of(studRepo.findById(id).get());
        return StreamSupport.stream(studList.spliterator(), false)
                .map(x->new FullStudent(x.id,x.name))
                .peek(x->x.grades=gradesRepo.findAllByStudent(x.id)
                    .stream().map(y->y.grade).collect(Collectors.toList()))
                .collect(Collectors.toList());   
    }
}
