/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webstudentlist.repository;

import org.springframework.data.annotation.Id;

/**
 *
 * @author Александр
 */
public class Grades {
    @Id
    Integer id;
    Integer grade;
    Integer student;

    @Override
    public String toString() {
        return "Grade{" + "id=" + id + ", grade=" + grade + ", student=" + student + '}';
    }
    
}
