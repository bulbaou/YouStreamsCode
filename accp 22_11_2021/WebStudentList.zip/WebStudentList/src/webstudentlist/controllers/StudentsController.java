package webstudentlist.controllers;

import java.util.ArrayList;
import webstudentlist.repository.StudentRepo;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import webstudentlist.repository.FullStudent;
import webstudentlist.repository.FullStudentRepo;
import webstudentlist.repository.Grades;
import webstudentlist.repository.GradesRepo;
import webstudentlist.repository.Student;

@Controller
@RequestMapping("/studs")
public class StudentsController {
    @Autowired
    FullStudentRepo studs;
    
    @RequestMapping(method = RequestMethod.GET)
    public String printHello(ModelMap model) {       
        
        model.addAttribute("message", studs.findAll());
        return "students";
    }
}
