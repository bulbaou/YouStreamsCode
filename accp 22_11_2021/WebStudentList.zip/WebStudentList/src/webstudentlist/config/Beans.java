package webstudentlist.config;

import webstudentlist.repository.FullStudent;
import java.util.List;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Beans {
    @Bean
    public FullStudent studVasia(){
        return new FullStudent(1,"Liza",List.of(5,5,4));
    }
}
