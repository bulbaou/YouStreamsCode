package webstudentlist.config;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class DataBase {
   public static void select() throws Exception {
       Connection con = DriverManager.getConnection("jdbc:h2:D:\\programming\\StudentDB.db");
       Statement stm = con.createStatement();
       ResultSet rs= stm.executeQuery("SELECT * FROM STUDENT");
       while(rs.next()){
           System.out.println(rs.getString("NAME"));
       }
   }
   public static void create() throws Exception {
        Connection con = DriverManager.getConnection("jdbc:h2:D:\\programming\\StudentDB.db");
        Statement stm = con.createStatement();
        stm.execute("CREATE TABLE STUDENT(ID INT PRIMARY KEY, NAME VARCHAR(255))");
        stm.execute("INSERT INTO STUDENT VALUES(1,'Vasia')");
        stm.execute("INSERT INTO STUDENT VALUES(2,'Petia')");
        stm.execute("INSERT INTO STUDENT VALUES(3,'Anna')");
        
        stm.execute("CREATE TABLE GRADES(ID INT PRIMARY KEY, GRADE INT, STUDENT INT)");
        stm.execute("INSERT INTO GRADES VALUES(1,3,1)");
        stm.execute("INSERT INTO GRADES VALUES(2,4,1)");
        stm.execute("INSERT INTO GRADES VALUES(3,5,1)");
        stm.execute("INSERT INTO GRADES VALUES(4,3,1)");
        stm.execute("INSERT INTO GRADES VALUES(5,2,1)");
        stm.execute("INSERT INTO GRADES VALUES(6,3,2)");
        stm.execute("INSERT INTO GRADES VALUES(7,5,2)");
        stm.execute("INSERT INTO GRADES VALUES(8,5,2)");
        stm.execute("INSERT INTO GRADES VALUES(9,4,2)");
    }
}

