package webstudentlist.config;

import java.util.Enumeration;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@ComponentScan("webstudentlist")
@Configuration
public class App {
    {System.out.println("\n\n--------APPP-------");}
    
    @Bean
    public InternalResourceViewResolver getResolver(){
        InternalResourceViewResolver r= new InternalResourceViewResolver();
        r.setPrefix("/WEB-INF/jsp/");
        r.setSuffix(".jsp");
        Enumeration e=null;
        
        return r;
    }
}

